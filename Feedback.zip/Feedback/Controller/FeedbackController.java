package com.example.demo.Controller;

import com.example.demo.Entity.Feedback;
import com.example.demo.Repository.FeedbackRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/feedback")
@Tag(name = "Feedback Controller", description = "Feedback management APIs")
public class FeedbackController {
    private final FeedbackRepository feedbackRepository;

    public FeedbackController(FeedbackRepository feedbackRepository) {
        this.feedbackRepository = feedbackRepository;
    }

    @PostMapping
    @Operation(summary = "Create feedback")
    public ResponseEntity<Feedback> createFeedback(@RequestBody Feedback feedback) {
        feedback.setFeedbackId(null);
        return ResponseEntity.status(HttpStatus.CREATED).body(feedbackRepository.save(feedback));
    }

    @GetMapping
    @Operation(summary = "Get all feedback")
    public ResponseEntity<List<Feedback>> getAllFeedback() {
        return ResponseEntity.ok(feedbackRepository.findAll());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get feedback by ID")
    public ResponseEntity<Feedback> getFeedbackById(@PathVariable Long id) {
        return feedbackRepository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get feedback by user ID")
    public ResponseEntity<List<Feedback>> getFeedbackByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(feedbackRepository.findByUserId(userId));
    }

    @GetMapping("/order/{orderId}")
    @Operation(summary = "Get feedback by order ID")
    public ResponseEntity<List<Feedback>> getFeedbackByOrderId(@PathVariable Long orderId) {
        return ResponseEntity.ok(feedbackRepository.findByOrderId(orderId));
    }

    @GetMapping("/partner/{partnerId}")
    @Operation(summary = "Get feedback by partner ID")
    public ResponseEntity<List<Feedback>> getFeedbackByPartnerId(@PathVariable Long partnerId) {
        return ResponseEntity.ok(feedbackRepository.findByPartnerId(partnerId));
    }

    @GetMapping("/rating/{rating}")
    @Operation(summary = "Get feedback by rating")
    public ResponseEntity<List<Feedback>> getFeedbackByRating(@PathVariable Integer rating) {
        return ResponseEntity.ok(feedbackRepository.findByRating(rating));
    }

    @GetMapping("/category/{category}")
    @Operation(summary = "Get feedback by category")
    public ResponseEntity<List<Feedback>> getFeedbackByCategory(@PathVariable String category) {
        return ResponseEntity.ok(feedbackRepository.findByFeedbackCategoryIgnoreCase(category));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update feedback by ID")
    public ResponseEntity<Feedback> updateFeedback(@PathVariable Long id, @RequestBody Feedback updatedFeedback) {
        return feedbackRepository.findById(id).map(feedback -> {
            feedback.setUserId(updatedFeedback.getUserId());
            feedback.setOrderId(updatedFeedback.getOrderId());
            feedback.setPartnerId(updatedFeedback.getPartnerId());
            feedback.setRating(updatedFeedback.getRating());
            feedback.setComment(updatedFeedback.getComment());
            feedback.setFeedbackCategory(updatedFeedback.getFeedbackCategory());
            return ResponseEntity.ok(feedbackRepository.save(feedback));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Partially update feedback by ID")
    public ResponseEntity<Feedback> patchFeedback(@PathVariable Long id, @RequestBody Map<String, Object> updates) {
        return feedbackRepository.findById(id).map(feedback -> {
            if (updates.containsKey("userId")) {
                Object value = updates.get("userId");
                feedback.setUserId(value == null ? null : Long.valueOf(value.toString()));
            }
            if (updates.containsKey("orderId")) {
                Object value = updates.get("orderId");
                feedback.setOrderId(value == null ? null : Long.valueOf(value.toString()));
            }
            if (updates.containsKey("partnerId")) {
                Object value = updates.get("partnerId");
                feedback.setPartnerId(value == null ? null : Long.valueOf(value.toString()));
            }
            if (updates.containsKey("rating")) {
                Object value = updates.get("rating");
                feedback.setRating(value == null ? null : Integer.valueOf(value.toString()));
            }
            if (updates.containsKey("comment")) {
                Object value = updates.get("comment");
                feedback.setComment(value == null ? null : value.toString());
            }
            if (updates.containsKey("feedbackCategory")) {
                Object value = updates.get("feedbackCategory");
                feedback.setFeedbackCategory(value == null ? null : value.toString());
            }
            return ResponseEntity.ok(feedbackRepository.save(feedback));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete feedback by ID")
    public ResponseEntity<Void> deleteFeedback(@PathVariable Long id) {
        if (!feedbackRepository.existsById(id)) return ResponseEntity.notFound().build();
        feedbackRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
