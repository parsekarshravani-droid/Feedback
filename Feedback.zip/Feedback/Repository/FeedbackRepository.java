package com.example.demo.Repository;

import com.example.demo.Entity.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    List<Feedback> findByUserId(Long userId);
    List<Feedback> findByOrderId(Long orderId);
    List<Feedback> findByPartnerId(Long partnerId);
    List<Feedback> findByRating(Integer rating);
    List<Feedback> findByFeedbackCategoryIgnoreCase(String feedbackCategory);
}
